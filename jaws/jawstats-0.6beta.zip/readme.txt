JAWStats Installation guide can be found at:
http://www.jawstats.com/manual